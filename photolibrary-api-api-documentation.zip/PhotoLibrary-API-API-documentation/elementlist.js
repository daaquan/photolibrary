
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","PhotoLibrary\\Album"],["c","PhotoLibrary\\Face"],["c","PhotoLibrary\\Library"],["c","PhotoLibrary\\Photo"]];
